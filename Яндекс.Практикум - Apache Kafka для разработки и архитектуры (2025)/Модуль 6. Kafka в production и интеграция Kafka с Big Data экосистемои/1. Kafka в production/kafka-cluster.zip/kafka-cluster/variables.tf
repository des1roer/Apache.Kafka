
variable "name" {
  description = "The name of the Kafka cluster."
  type        = string
}


variable "network_id" {
  description = "The ID of the VPC network where the cluster will be deployed."
  type        = string
}

variable "subnet_ids" {
  description = "A list of subnet IDs to deploy the cluster in."
  type        = list(string)
}


variable "zones" {
  description = "A list of availability zones."
  type        = list(string)
}


variable "brokers_count" {
  description = "The number of brokers."
  type        = number
}

variable "folder_id" {
  description = "Folder id that contains the MongoDB cluster"
  type        = string
  default     = null
}


