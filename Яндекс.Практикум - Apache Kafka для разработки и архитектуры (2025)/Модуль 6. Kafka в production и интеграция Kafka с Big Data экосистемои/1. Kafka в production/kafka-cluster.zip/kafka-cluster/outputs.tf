output "cluster_id" {
  description = "Kafka cluster ID"
  value       = module.kafka_cluster.cluster_id
}

output "cluster_name" {
  description = "Kafka cluster name"
  value       = module.kafka_cluster.cluster_name
}

output "cluster_host_names_list" {
  description = "Kafka cluster host name"
  value       = module.kafka_cluster.cluster_host_names_list
}
