### Datasource
data "yandex_client_config" "client" {}

### Locals
locals {
  folder_id = var.folder_id == null ? data.yandex_client_config.client.folder_id : var.folder_id
}

module "kafka_cluster" {
  source = "./modules/kafka/cluster"
  brokers_count = var.brokers_count
  name = var.name
  network_id = var.network_id
  subnet_ids = var.subnet_ids
  zones = var.zones
}

