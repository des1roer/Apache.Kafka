network_id = "ххх"
brokers_count = 1
name = "Kafka"
subnet_ids = ["ххх"]
zones = ["ru-central1-a"]
